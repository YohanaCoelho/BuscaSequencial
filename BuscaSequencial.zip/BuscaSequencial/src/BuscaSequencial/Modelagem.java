package BuscaSequencial;

public class Modelagem {
	
	    // Esta classe não contém nenhum código Java, pois a modelagem é abstrata e não é expressa diretamente no código.
	}


