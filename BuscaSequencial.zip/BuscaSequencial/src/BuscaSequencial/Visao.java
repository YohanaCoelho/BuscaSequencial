package BuscaSequencial;

public class Visao {
	
	    public static void main(String[] args) {
	        
	        int[] vetor = {54, 26, 93, 17, 77, 31, 44, 55, 20, 65};
	        int elementoParaEncontrar = 93;
	        int resultado = Construtor.buscaSequencial(vetor, elementoParaEncontrar);
	        
	        if(resultado != -1) {
	            System.out.println("Elemento encontrado no índice: " + resultado);
	        } else {
	            System.out.println("Elemento não encontrado no índice");
	        }
	    }
	}


