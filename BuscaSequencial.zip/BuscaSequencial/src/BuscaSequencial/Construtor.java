package BuscaSequencial;


public class Construtor {
   
    public static int buscaSequencial(int[] vetor, int elementoParaEncontrar) {
        for(int i = 0; i < vetor.length; i++) {
            if (vetor[i] == elementoParaEncontrar) {
                return i;
            }
        }
        return -1;
    }
}


