/**
 * 
 */
/**
 * 
 */
module BuscaSequencial {
}